import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { LoadingAnimation } from '../components/Loading';

const Create = () => {
  const [title, setTitle] = useState('');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [isForSale, setIsForSale] = useState(false);
  const [price, setPrice] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleImageUpload = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile)); // for preview
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !file) {
      return toast.error('Title and image are required');
    }

    if (isForSale && (!price || isNaN(price) || Number(price) <= 0)) {
      return toast.error('Please enter a valid price');
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('file', file);
    formData.append('isForSale', isForSale);
    if (isForSale) {
      formData.append('price', price);
    }

    try {
      setLoading(true);
      const token = localStorage.getItem('token');

      const { data } = await axios.post('/api/pin/new', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`,
        },
      });

      toast.success(data.message);
      navigate('/');
    } catch (error) {
      console.error('Create pin error:', error.response?.data || error.message);
      toast.error(error.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-semibold mb-4">Create a New Pin</h2>
      <form onSubmit={handleSubmit}>
        {/* Title */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="common-input"
            required
          />
        </div>

        {/* Image */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">Image</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="common-input"
            required
          />
        </div>

        {/* Image Preview */}
        {preview && (
          <div className="mb-4">
            <img src={preview} alt="Preview" className="w-full rounded" />
          </div>
        )}

        {/* For Sale Toggle */}
        <div className="mb-4 flex items-center gap-2">
          <input
            type="checkbox"
            checked={isForSale}
            onChange={() => setIsForSale(!isForSale)}
            id="forSaleToggle"
          />
          <label htmlFor="forSaleToggle" className="text-sm font-medium text-gray-700">
            Mark as For Sale
          </label>
        </div>

        {/* Price Input (Only if For Sale) */}
        {isForSale && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Price (৳)</label>
            <input
              type="number"
              min="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="common-input"
              placeholder="Enter price in BDT"
              required
            />
          </div>
        )}

        {/* Submit Button */}
        <button type="submit" className="common-btn" disabled={loading}>
          {loading ? <LoadingAnimation /> : 'Create Pin'}
        </button>
      </form>
    </div>
  );
};

export default Create;

import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../images/Logo3.png';

const Navbar = ({user}) => {
  return (
    <div className='bg-white shadow-sm'>
      <div className='mx-auto px-4 py-2 flex items-center justify-between'>

        <Link to="/" className="flex items-center space-x-2">
          <img src={logo} alt='Aesthetes Gallery' className='h-8' />
          <span className='text-red-600 text-3xl font-bold italic font-playfair'>
            | Aesthete's Gallery
          </span>
        </Link>

        <div className='flex items-center space-x-4'>
          <Link to="/" className='text-gray-700 hover:text-gray-900'>Home</Link>
          <Link to="/create" className='text-gray-700 hover:text-gray-900'>Create</Link>
          <Link to="/account" className='w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-xl text-gray-700'>{user.name.slice(0,1)}</Link>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
